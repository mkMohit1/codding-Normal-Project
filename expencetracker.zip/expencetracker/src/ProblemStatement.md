### Set up and initialize a Cloud Firestore project, and use it to add and update expenses in the React application.

Add a new document to the collection when the user submits the ExpenseForm. If the user selects the update option in the ExpenseForm, the corresponding document in the database should be updated.
